return {
    window_swallowing = require(... .. ".window_swallowing"),
    tiled_wallpaper = require(... .. ".tiled_wallpaper"),
    wallpaper = require(... .. ".wallpaper"),
    flash_focus = require(... .. ".flash_focus"),
    tabbed = require(... .. ".tabbed"),
    scratchpad = require(... .. ".scratchpad"),
}
