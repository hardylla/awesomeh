return {
    titlebar_indicator = require(
        tostring(...):match(".*bling")
            .. ".widget.tabbed_misc.titlebar_indicator"
    ),
    custom_tasklist = require(
        tostring(...):match(".*bling") .. ".widget.tabbed_misc.custom_tasklist"
    ),
}
